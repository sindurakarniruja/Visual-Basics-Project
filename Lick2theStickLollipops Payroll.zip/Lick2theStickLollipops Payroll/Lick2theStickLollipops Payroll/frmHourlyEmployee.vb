﻿Public Class frmHourlyEmployee

    'Main calculate button click event. Gets and validates inputs,
    'calculates and displays results if all inputs are valid.
    Private Sub btnHourlyCalculate_Click(sender As Object, e As EventArgs) Handles btnHourlyCalculate.Click

        'Declaring Variables
        Dim strFirstName As String
        Dim strLastName As String
        Dim strState As String
        Dim decHoursWorked As Decimal
        Dim decHourlyWage As Decimal
        Dim decYTDGrossPay As Decimal
        Dim decGrossPay As Decimal
        Dim decSocialSecurity As Decimal
        Dim decMedicare As Decimal
        Dim decFICA As Decimal
        Dim decStateTax As Decimal
        Dim decFederalTax As Decimal
        Dim decNetPay As Decimal
        Dim blnValidated As Boolean = True

        'Call procedure to get and validate inputs
        Call Get_And_Validate_Inputs(strFirstName, strLastName, strState, decHoursWorked, decHourlyWage, decYTDGrossPay, blnValidated)

        'Only calculate and display if all inputs are valid
        If blnValidated = True Then
            'Call procedure to perform all calculations
            Call Calculate_All(decHoursWorked, decHourlyWage, decYTDGrossPay, strState, decGrossPay, decSocialSecurity,
                               decMedicare, decFICA, decStateTax, decFederalTax, decNetPay)

            'Call procedure to display results
            Call Display_Results(decGrossPay, decFICA, decStateTax, decFederalTax, decNetPay)
        End If

    End Sub

    'GET & VALIDATE INPUT
    'Calls each individual validation sub in order.
    'If any validation fails, blnValidated is set to False and remaining checks are skipped.
    'CORRECT
    Private Sub Get_And_Validate_Inputs(ByRef strFirstName As String, ByRef strLastName As String,
                                    ByRef strState As String, ByRef decHoursWorked As Decimal,
                                    ByRef decHourlyWage As Decimal, ByRef decYTDGrossPay As Decimal,
                                    ByRef blnValidated As Boolean)
        Call Get_Validate_FirstName(blnValidated, strFirstName)
        If blnValidated = True Then
            Call Get_Validate_LastName(blnValidated, strLastName)
            If blnValidated = True Then
                Call Get_Validate_HoursWorked(decHoursWorked, blnValidated)
                If blnValidated = True Then
                    Call Get_Validate_HourlyWage(decHourlyWage, blnValidated)
                    If blnValidated = True Then
                        Call Get_Validate_YTDGrossPay(decYTDGrossPay, blnValidated)
                        If blnValidated = True Then
                            strState = Get_State()
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    'Ensures First Name field is not left empty
    Private Sub Get_Validate_FirstName(ByRef blnValidated As Boolean, ByRef strFirstName As String)
        If txtHourlyFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required!")
            txtHourlyFirstName.Focus()
            blnValidated = False
        Else
            strFirstName = txtHourlyFirstName.Text
        End If
    End Sub

    'Ensures Last Name field is not left empty
    Private Sub Get_Validate_LastName(ByRef blnValidated As Boolean, ByRef strLastName As String)
        If txtHourlyLastName.Text = String.Empty Then
            MessageBox.Show("Last Name is Required!")
            txtHourlyLastName.Focus()
            blnValidated = False
        Else
            strLastName = txtHourlyLastName.Text
        End If
    End Sub

    'Ensures Hours Worked exists, is numeric, and greater than 0
    Private Sub Get_Validate_HoursWorked(ByRef decHoursWorked As Decimal, ByRef blnValidated As Boolean)
        If Decimal.TryParse(txtHourlyHoursWorked.Text, decHoursWorked) Then
            If decHoursWorked > 0 Then
            Else
                MessageBox.Show("Hours Worked must be greater than 0!")
                txtHourlyHoursWorked.Focus()
                blnValidated = False
            End If
        Else
            MessageBox.Show("Hours Worked must exist and be numeric!")
            txtHourlyHoursWorked.Focus()
            blnValidated = False
        End If
    End Sub

    'Ensures Hourly Wage exists, is numeric, and greater than 0
    Private Sub Get_Validate_HourlyWage(ByRef decHourlyWage As Decimal, ByRef blnValidated As Boolean)
        If Decimal.TryParse(txtHourlyHourlywage.Text, decHourlyWage) Then
            If decHourlyWage > 0 Then
            Else
                MessageBox.Show("Hourly Wage must be greater than 0!")
                txtHourlyHourlywage.Focus()
                blnValidated = False
            End If
        Else
            MessageBox.Show("Hourly Wage must exist and be numeric!")
            txtHourlyHourlywage.Focus()
            blnValidated = False
        End If
    End Sub

    'Ensures YTD Gross Pay exists, is numeric, and greater than or equal to 0
    Private Sub Get_Validate_YTDGrossPay(ByRef decYTDGrossPay As Decimal, ByRef blnValidated As Boolean)
        If Decimal.TryParse(txtHourlyYTDGrossPay.Text, decYTDGrossPay) Then
            If decYTDGrossPay >= 0 Then
            Else
                MessageBox.Show("YTD Gross Pay must be greater than or equal to 0!")
                txtHourlyYTDGrossPay.Focus()
                blnValidated = False
            End If
        Else
            MessageBox.Show("YTD Gross Pay must exist and be numeric!")
            txtHourlyYTDGrossPay.Focus()
            blnValidated = False
        End If
    End Sub

    'Gets selected state from radio buttons
    Private Function Get_State() As String
        If radHourlyOhio.Checked = True Then
            Return "Ohio"
        ElseIf radHourlyKentucky.Checked = True Then
            Return "Kentucky"
        Else
            Return "Indiana"
        End If
    End Function

    'Calls each individual calculation function or procedures in order
    Private Sub Calculate_All(ByVal decHoursWorked As Decimal, ByVal decHourlyWage As Decimal,
                               ByVal decYTDGrossPay As Decimal, ByVal strState As String,
                               ByRef decGrossPay As Decimal, ByRef decSocialSecurity As Decimal,
                               ByRef decMedicare As Decimal, ByRef decFICA As Decimal,
                               ByRef decStateTax As Decimal, ByRef decFederalTax As Decimal,
                               ByRef decNetPay As Decimal)

        decGrossPay = Calculate_GrossPay(decHoursWorked, decHourlyWage)
        decSocialSecurity = Calculate_SocialSecurity(decYTDGrossPay, decGrossPay)
        decMedicare = Calculate_Medicare(decGrossPay)
        decFICA = Calculate_FICA(decSocialSecurity, decMedicare)
        decStateTax = Calculate_StateTax(decGrossPay, strState)
        decFederalTax = Calculate_FederalTax(decGrossPay)
        decNetPay = Calculate_NetPay(decGrossPay, decFICA, decStateTax, decFederalTax)
        Call Calculate_DailyGrossPay(decGrossPay)
        Call Calculate_DailyNetPay(decNetPay)
    End Sub

    'Calculates Gross Pay based on Hours Worked and Hourly Wage with overtime
    Private Function Calculate_GrossPay(ByVal decHoursWorked As Decimal, ByVal decHourlyWage As Decimal) As Decimal
        If decHoursWorked <= 40 Then
            Return decHoursWorked * decHourlyWage
        Else
            Return (40 * decHourlyWage) + ((decHoursWorked - 40) * decHourlyWage * 1.5)
        End If
    End Function

    'Displays all calculated results to the form labels
    Private Sub Display_Results(ByVal decGrossPay As Decimal, ByVal decFICA As Decimal,
                                 ByVal decStateTax As Decimal, ByVal decFederalTax As Decimal,
                                 ByVal decNetPay As Decimal)

        lblHourlyDisplayGrossPay.Text = decGrossPay.ToString("C")
        lblHourlyDisplayFICA.Text = decFICA.ToString("C")
        lblHourlyDisplayStateTax.Text = decStateTax.ToString("C")
        lblHourlyDisplayFederalTax.Text = decFederalTax.ToString("C")
        lblHourlyDisplayNetPay.Text = decNetPay.ToString("C")

    End Sub

    'Clears all inputs and outputs for next entry
    Private Sub btnHourlyClear_Click(sender As Object, e As EventArgs) Handles btnHourlyClear.Click

        'Clear all text boxes
        txtHourlyFirstName.Clear()
        txtHourlyLastName.Clear()
        txtHourlyHoursWorked.Clear()
        txtHourlyHourlywage.Clear()
        txtHourlyYTDGrossPay.Clear()

        'Reset radio buttons
        radHourlyOhio.Checked = False
        radHourlyKentucky.Checked = False
        radHourlyIndiana.Checked = True

        'Clear output labels
        lblHourlyDisplayGrossPay.ResetText()
        lblHourlyDisplayFICA.ResetText()
        lblHourlyDisplayStateTax.ResetText()
        lblHourlyDisplayFederalTax.ResetText()
        lblHourlyDisplayNetPay.ResetText()

        'Set focus back to first name
        txtHourlyFirstName.Focus()

    End Sub

    'Closes the Hourly Employee form
    Private Sub btnHourlyClose_Click(sender As Object, e As EventArgs) Handles btnHourlyExit.Click
        Close()
    End Sub

    'Menu item that mimics the Calculate button
    Private Sub mnuCalculate_Click(sender As Object, e As EventArgs) Handles mnuCalculate.Click
        btnHourlyCalculate_Click(sender, e)
    End Sub

    'Menu item that mimics the Clear button
    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        btnHourlyClear_Click(sender, e)
    End Sub

    'Menu item that mimics the Exit button
    Private Sub mnuExitForm_Click(sender As Object, e As EventArgs) Handles mnuExitForm.Click
        btnHourlyClose_Click(sender, e)
    End Sub
End Class
