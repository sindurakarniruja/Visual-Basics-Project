﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSalariedEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSalariedinputs = New System.Windows.Forms.GroupBox()
        Me.txtSalariedYTDGrossPay = New System.Windows.Forms.TextBox()
        Me.txtSalariedYearlySalary = New System.Windows.Forms.TextBox()
        Me.txtSalariedLastName = New System.Windows.Forms.TextBox()
        Me.lblSalariedYTDGrossPay = New System.Windows.Forms.Label()
        Me.lblSalariedYearlySalary = New System.Windows.Forms.Label()
        Me.lblSalariedLastName = New System.Windows.Forms.Label()
        Me.lblSalariedFirstName = New System.Windows.Forms.Label()
        Me.txtSalariedFirstName = New System.Windows.Forms.TextBox()
        Me.grbSalariedState = New System.Windows.Forms.GroupBox()
        Me.radSalariedOhio = New System.Windows.Forms.RadioButton()
        Me.radSalariedKentucky = New System.Windows.Forms.RadioButton()
        Me.radSalariedIndiana = New System.Windows.Forms.RadioButton()
        Me.btnSalariedCalculate = New System.Windows.Forms.Button()
        Me.btnSalariedClear = New System.Windows.Forms.Button()
        Me.btnSalariedExit = New System.Windows.Forms.Button()
        Me.grpSalaryOutput = New System.Windows.Forms.GroupBox()
        Me.lblSalariedDisplayNetPay = New System.Windows.Forms.Label()
        Me.lblSalariedDisplayFederalTax = New System.Windows.Forms.Label()
        Me.lblSalariedDisplayStateTax = New System.Windows.Forms.Label()
        Me.lblSalariedDisplayFICA = New System.Windows.Forms.Label()
        Me.lblSalariedDisplayGrossPay = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ActionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCalculate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.grpSalariedinputs.SuspendLayout()
        Me.grbSalariedState.SuspendLayout()
        Me.grpSalaryOutput.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSalariedinputs
        '
        Me.grpSalariedinputs.Controls.Add(Me.txtSalariedYTDGrossPay)
        Me.grpSalariedinputs.Controls.Add(Me.txtSalariedYearlySalary)
        Me.grpSalariedinputs.Controls.Add(Me.txtSalariedLastName)
        Me.grpSalariedinputs.Controls.Add(Me.lblSalariedYTDGrossPay)
        Me.grpSalariedinputs.Controls.Add(Me.lblSalariedYearlySalary)
        Me.grpSalariedinputs.Controls.Add(Me.lblSalariedLastName)
        Me.grpSalariedinputs.Controls.Add(Me.lblSalariedFirstName)
        Me.grpSalariedinputs.Controls.Add(Me.txtSalariedFirstName)
        Me.grpSalariedinputs.Location = New System.Drawing.Point(12, 57)
        Me.grpSalariedinputs.Name = "grpSalariedinputs"
        Me.grpSalariedinputs.Size = New System.Drawing.Size(319, 184)
        Me.grpSalariedinputs.TabIndex = 6
        Me.grpSalariedinputs.TabStop = False
        '
        'txtSalariedYTDGrossPay
        '
        Me.txtSalariedYTDGrossPay.Location = New System.Drawing.Point(138, 129)
        Me.txtSalariedYTDGrossPay.Multiline = True
        Me.txtSalariedYTDGrossPay.Name = "txtSalariedYTDGrossPay"
        Me.txtSalariedYTDGrossPay.Size = New System.Drawing.Size(100, 26)
        Me.txtSalariedYTDGrossPay.TabIndex = 4
        '
        'txtSalariedYearlySalary
        '
        Me.txtSalariedYearlySalary.Location = New System.Drawing.Point(138, 97)
        Me.txtSalariedYearlySalary.Multiline = True
        Me.txtSalariedYearlySalary.Name = "txtSalariedYearlySalary"
        Me.txtSalariedYearlySalary.Size = New System.Drawing.Size(100, 26)
        Me.txtSalariedYearlySalary.TabIndex = 3
        '
        'txtSalariedLastName
        '
        Me.txtSalariedLastName.Location = New System.Drawing.Point(138, 65)
        Me.txtSalariedLastName.Multiline = True
        Me.txtSalariedLastName.Name = "txtSalariedLastName"
        Me.txtSalariedLastName.Size = New System.Drawing.Size(100, 26)
        Me.txtSalariedLastName.TabIndex = 2
        '
        'lblSalariedYTDGrossPay
        '
        Me.lblSalariedYTDGrossPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedYTDGrossPay.Location = New System.Drawing.Point(6, 132)
        Me.lblSalariedYTDGrossPay.Name = "lblSalariedYTDGrossPay"
        Me.lblSalariedYTDGrossPay.Size = New System.Drawing.Size(135, 24)
        Me.lblSalariedYTDGrossPay.TabIndex = 10
        Me.lblSalariedYTDGrossPay.Text = "YTD Gross Pay:"
        Me.lblSalariedYTDGrossPay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSalariedYearlySalary
        '
        Me.lblSalariedYearlySalary.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedYearlySalary.Location = New System.Drawing.Point(6, 99)
        Me.lblSalariedYearlySalary.Name = "lblSalariedYearlySalary"
        Me.lblSalariedYearlySalary.Size = New System.Drawing.Size(114, 20)
        Me.lblSalariedYearlySalary.TabIndex = 9
        Me.lblSalariedYearlySalary.Text = "Yearly Salary:"
        Me.lblSalariedYearlySalary.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblSalariedLastName
        '
        Me.lblSalariedLastName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedLastName.Location = New System.Drawing.Point(6, 68)
        Me.lblSalariedLastName.Name = "lblSalariedLastName"
        Me.lblSalariedLastName.Size = New System.Drawing.Size(114, 20)
        Me.lblSalariedLastName.TabIndex = 8
        Me.lblSalariedLastName.Text = "Last Name:"
        Me.lblSalariedLastName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSalariedFirstName
        '
        Me.lblSalariedFirstName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedFirstName.Location = New System.Drawing.Point(6, 35)
        Me.lblSalariedFirstName.Name = "lblSalariedFirstName"
        Me.lblSalariedFirstName.Size = New System.Drawing.Size(114, 20)
        Me.lblSalariedFirstName.TabIndex = 0
        Me.lblSalariedFirstName.Text = "First Name:"
        Me.lblSalariedFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtSalariedFirstName
        '
        Me.txtSalariedFirstName.Location = New System.Drawing.Point(138, 32)
        Me.txtSalariedFirstName.Multiline = True
        Me.txtSalariedFirstName.Name = "txtSalariedFirstName"
        Me.txtSalariedFirstName.Size = New System.Drawing.Size(100, 26)
        Me.txtSalariedFirstName.TabIndex = 1
        '
        'grbSalariedState
        '
        Me.grbSalariedState.Controls.Add(Me.radSalariedOhio)
        Me.grbSalariedState.Controls.Add(Me.radSalariedKentucky)
        Me.grbSalariedState.Controls.Add(Me.radSalariedIndiana)
        Me.grbSalariedState.Location = New System.Drawing.Point(339, 80)
        Me.grbSalariedState.Name = "grbSalariedState"
        Me.grbSalariedState.Size = New System.Drawing.Size(200, 148)
        Me.grbSalariedState.TabIndex = 7
        Me.grbSalariedState.TabStop = False
        Me.grbSalariedState.Text = "State"
        '
        'radSalariedOhio
        '
        Me.radSalariedOhio.AutoSize = True
        Me.radSalariedOhio.Location = New System.Drawing.Point(16, 109)
        Me.radSalariedOhio.Name = "radSalariedOhio"
        Me.radSalariedOhio.Size = New System.Drawing.Size(67, 24)
        Me.radSalariedOhio.TabIndex = 7
        Me.radSalariedOhio.Text = "Ohio"
        Me.radSalariedOhio.UseVisualStyleBackColor = True
        '
        'radSalariedKentucky
        '
        Me.radSalariedKentucky.AutoSize = True
        Me.radSalariedKentucky.Location = New System.Drawing.Point(16, 68)
        Me.radSalariedKentucky.Name = "radSalariedKentucky"
        Me.radSalariedKentucky.Size = New System.Drawing.Size(99, 24)
        Me.radSalariedKentucky.TabIndex = 6
        Me.radSalariedKentucky.Text = "Kentucky"
        Me.radSalariedKentucky.UseVisualStyleBackColor = True
        '
        'radSalariedIndiana
        '
        Me.radSalariedIndiana.AutoSize = True
        Me.radSalariedIndiana.Checked = True
        Me.radSalariedIndiana.Location = New System.Drawing.Point(16, 26)
        Me.radSalariedIndiana.Name = "radSalariedIndiana"
        Me.radSalariedIndiana.Size = New System.Drawing.Size(87, 24)
        Me.radSalariedIndiana.TabIndex = 5
        Me.radSalariedIndiana.TabStop = True
        Me.radSalariedIndiana.Text = "Indiana"
        Me.radSalariedIndiana.UseVisualStyleBackColor = True
        '
        'btnSalariedCalculate
        '
        Me.btnSalariedCalculate.Location = New System.Drawing.Point(78, 261)
        Me.btnSalariedCalculate.Name = "btnSalariedCalculate"
        Me.btnSalariedCalculate.Size = New System.Drawing.Size(98, 31)
        Me.btnSalariedCalculate.TabIndex = 8
        Me.btnSalariedCalculate.Text = "Calculate"
        Me.btnSalariedCalculate.UseVisualStyleBackColor = True
        '
        'btnSalariedClear
        '
        Me.btnSalariedClear.Location = New System.Drawing.Point(196, 261)
        Me.btnSalariedClear.Name = "btnSalariedClear"
        Me.btnSalariedClear.Size = New System.Drawing.Size(98, 31)
        Me.btnSalariedClear.TabIndex = 9
        Me.btnSalariedClear.Text = "Clear"
        Me.btnSalariedClear.UseVisualStyleBackColor = True
        '
        'btnSalariedExit
        '
        Me.btnSalariedExit.Location = New System.Drawing.Point(324, 261)
        Me.btnSalariedExit.Name = "btnSalariedExit"
        Me.btnSalariedExit.Size = New System.Drawing.Size(98, 31)
        Me.btnSalariedExit.TabIndex = 10
        Me.btnSalariedExit.Text = "Exit"
        Me.btnSalariedExit.UseVisualStyleBackColor = True
        '
        'grpSalaryOutput
        '
        Me.grpSalaryOutput.Controls.Add(Me.lblSalariedDisplayNetPay)
        Me.grpSalaryOutput.Controls.Add(Me.lblSalariedDisplayFederalTax)
        Me.grpSalaryOutput.Controls.Add(Me.lblSalariedDisplayStateTax)
        Me.grpSalaryOutput.Controls.Add(Me.lblSalariedDisplayFICA)
        Me.grpSalaryOutput.Controls.Add(Me.lblSalariedDisplayGrossPay)
        Me.grpSalaryOutput.Controls.Add(Me.lbl5)
        Me.grpSalaryOutput.Controls.Add(Me.lbl4)
        Me.grpSalaryOutput.Controls.Add(Me.lbl3)
        Me.grpSalaryOutput.Controls.Add(Me.lbl2)
        Me.grpSalaryOutput.Controls.Add(Me.lbl1)
        Me.grpSalaryOutput.Location = New System.Drawing.Point(89, 311)
        Me.grpSalaryOutput.Name = "grpSalaryOutput"
        Me.grpSalaryOutput.Size = New System.Drawing.Size(321, 200)
        Me.grpSalaryOutput.TabIndex = 11
        Me.grpSalaryOutput.TabStop = False
        Me.grpSalaryOutput.Text = "Results"
        '
        'lblSalariedDisplayNetPay
        '
        Me.lblSalariedDisplayNetPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedDisplayNetPay.Location = New System.Drawing.Point(140, 161)
        Me.lblSalariedDisplayNetPay.Name = "lblSalariedDisplayNetPay"
        Me.lblSalariedDisplayNetPay.Size = New System.Drawing.Size(100, 23)
        Me.lblSalariedDisplayNetPay.TabIndex = 12
        '
        'lblSalariedDisplayFederalTax
        '
        Me.lblSalariedDisplayFederalTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedDisplayFederalTax.Location = New System.Drawing.Point(140, 133)
        Me.lblSalariedDisplayFederalTax.Name = "lblSalariedDisplayFederalTax"
        Me.lblSalariedDisplayFederalTax.Size = New System.Drawing.Size(100, 23)
        Me.lblSalariedDisplayFederalTax.TabIndex = 8
        '
        'lblSalariedDisplayStateTax
        '
        Me.lblSalariedDisplayStateTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedDisplayStateTax.Location = New System.Drawing.Point(140, 101)
        Me.lblSalariedDisplayStateTax.Name = "lblSalariedDisplayStateTax"
        Me.lblSalariedDisplayStateTax.Size = New System.Drawing.Size(100, 23)
        Me.lblSalariedDisplayStateTax.TabIndex = 7
        '
        'lblSalariedDisplayFICA
        '
        Me.lblSalariedDisplayFICA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedDisplayFICA.Location = New System.Drawing.Point(140, 68)
        Me.lblSalariedDisplayFICA.Name = "lblSalariedDisplayFICA"
        Me.lblSalariedDisplayFICA.Size = New System.Drawing.Size(100, 23)
        Me.lblSalariedDisplayFICA.TabIndex = 6
        '
        'lblSalariedDisplayGrossPay
        '
        Me.lblSalariedDisplayGrossPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSalariedDisplayGrossPay.Location = New System.Drawing.Point(140, 36)
        Me.lblSalariedDisplayGrossPay.Name = "lblSalariedDisplayGrossPay"
        Me.lblSalariedDisplayGrossPay.Size = New System.Drawing.Size(100, 23)
        Me.lblSalariedDisplayGrossPay.TabIndex = 5
        '
        'lbl5
        '
        Me.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl5.Location = New System.Drawing.Point(25, 161)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(100, 23)
        Me.lbl5.TabIndex = 4
        Me.lbl5.Text = "Net Pay:"
        '
        'lbl4
        '
        Me.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl4.Location = New System.Drawing.Point(25, 130)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(100, 23)
        Me.lbl4.TabIndex = 3
        Me.lbl4.Text = "Federal Tax:"
        '
        'lbl3
        '
        Me.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl3.Location = New System.Drawing.Point(25, 99)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(100, 23)
        Me.lbl3.TabIndex = 2
        Me.lbl3.Text = "State Tax:"
        '
        'lbl2
        '
        Me.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl2.Location = New System.Drawing.Point(25, 66)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(100, 23)
        Me.lbl2.TabIndex = 1
        Me.lbl2.Text = "FICA:"
        '
        'lbl1
        '
        Me.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl1.Location = New System.Drawing.Point(25, 36)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(100, 23)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Gross Pay:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ActionsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(558, 33)
        Me.MenuStrip1.TabIndex = 12
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ActionsToolStripMenuItem
        '
        Me.ActionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCalculate, Me.mnuClear, Me.mnuExit})
        Me.ActionsToolStripMenuItem.Name = "ActionsToolStripMenuItem"
        Me.ActionsToolStripMenuItem.Size = New System.Drawing.Size(87, 29)
        Me.ActionsToolStripMenuItem.Text = "Actions"
        '
        'mnuCalculate
        '
        Me.mnuCalculate.Name = "mnuCalculate"
        Me.mnuCalculate.Size = New System.Drawing.Size(188, 34)
        Me.mnuCalculate.Text = "Calculate"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(188, 34)
        Me.mnuClear.Text = "Clear"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(188, 34)
        Me.mnuExit.Text = "Exit Form"
        '
        'frmSalariedEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 523)
        Me.Controls.Add(Me.grpSalaryOutput)
        Me.Controls.Add(Me.btnSalariedExit)
        Me.Controls.Add(Me.btnSalariedClear)
        Me.Controls.Add(Me.btnSalariedCalculate)
        Me.Controls.Add(Me.grbSalariedState)
        Me.Controls.Add(Me.grpSalariedinputs)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmSalariedEmployee"
        Me.Text = "Salaried Employee"
        Me.grpSalariedinputs.ResumeLayout(False)
        Me.grpSalariedinputs.PerformLayout()
        Me.grbSalariedState.ResumeLayout(False)
        Me.grbSalariedState.PerformLayout()
        Me.grpSalaryOutput.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpSalariedinputs As GroupBox
    Friend WithEvents txtSalariedYTDGrossPay As TextBox
    Friend WithEvents txtSalariedYearlySalary As TextBox
    Friend WithEvents txtSalariedLastName As TextBox
    Friend WithEvents lblSalariedYTDGrossPay As Label
    Friend WithEvents lblSalariedYearlySalary As Label
    Friend WithEvents lblSalariedLastName As Label
    Friend WithEvents lblSalariedFirstName As Label
    Friend WithEvents txtSalariedFirstName As TextBox
    Friend WithEvents grbSalariedState As GroupBox
    Friend WithEvents radSalariedOhio As RadioButton
    Friend WithEvents radSalariedKentucky As RadioButton
    Friend WithEvents radSalariedIndiana As RadioButton
    Friend WithEvents btnSalariedCalculate As Button
    Friend WithEvents btnSalariedClear As Button
    Friend WithEvents btnSalariedExit As Button
    Friend WithEvents grpSalaryOutput As GroupBox
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents lblSalariedDisplayNetPay As Label
    Friend WithEvents lblSalariedDisplayFederalTax As Label
    Friend WithEvents lblSalariedDisplayStateTax As Label
    Friend WithEvents lblSalariedDisplayFICA As Label
    Friend WithEvents lblSalariedDisplayGrossPay As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ActionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuCalculate As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
End Class
