﻿Public Class frmSalariedEmployee
    'Payroll Constants
    Const dec_PAYROLLS_PER_YEAR As Decimal = 52

    'Main calculate button click event. Gets and validates inputs,
    'then calculates and displays results if all inputs are valid.
    Private Sub btnSalariedCalculate_Click(sender As Object, e As EventArgs) Handles btnSalariedCalculate.Click

        'Declaring Variables
        Dim strFirstName As String
        Dim strLastName As String
        Dim strState As String
        Dim decYearlySalary As Decimal
        Dim decYTDGrossPay As Decimal
        Dim decGrossPay As Decimal
        Dim decSocialSecurity As Decimal
        Dim decMedicare As Decimal
        Dim decFICA As Decimal
        Dim decStateTax As Decimal
        Dim decFederalTax As Decimal
        Dim decNetPay As Decimal
        Dim blnValidated As Boolean = True

        'Call procedure to get and validate inputs
        Call Get_And_Validate_Inputs(strFirstName, strLastName, strState, decYearlySalary, decYTDGrossPay, blnValidated)

        'Only calculate and display if all inputs are valid
        If blnValidated = True Then
            'Call procedure to perform all calculations
            Call Calculate_All(decYearlySalary, decYTDGrossPay, strState, decGrossPay, decSocialSecurity,
                           decMedicare, decFICA, decStateTax, decFederalTax, decNetPay)
            'Call procedure to display results
            Call Display_Results(decGrossPay, decFICA, decStateTax, decFederalTax, decNetPay)
        End If
    End Sub

    'GET & VALIDATE INPUT
    'Calls each individual validation sub in order.
    'If any validation fails, blnValidated is set to False and remaining checks are skipped. 
    Private Sub Get_And_Validate_Inputs(ByRef strFirstName As String, ByRef strLastName As String, ByRef strState As String,
                                    ByRef decYearlySalary As Decimal, ByRef decYTDGrossPay As Decimal,
                                    ByRef blnValidated As Boolean)
        Call Get_Validate_FirstName(blnValidated, strFirstName)
        If blnValidated = True Then
            Call Get_Validate_LastName(blnValidated, strLastName)
            If blnValidated = True Then
                Call Get_Validate_YearlySalary(decYearlySalary, blnValidated)
                If blnValidated = True Then
                    Call Get_Validate_YTDGrossPay(decYTDGrossPay, blnValidated)
                End If
                If blnValidated = True Then
                    strState = Get_State()
                End If
            End If
        End If
    End Sub

    'Ensures First Name field is not left empty
    Private Sub Get_Validate_FirstName(ByRef blnValidated As Boolean, ByRef strFirstName As String)
        If txtSalariedFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required!")
            txtSalariedFirstName.Focus()
            blnValidated = False
        Else
            strFirstName = txtSalariedFirstName.Text
        End If
    End Sub

    'Ensures Last Name field is not left empty
    Private Sub Get_Validate_LastName(ByRef blnValidated As Boolean, ByRef strLastName As String)
        If txtSalariedLastName.Text = String.Empty Then
            MessageBox.Show("Last Name is Required!")
            txtSalariedLastName.Focus()
            blnValidated = False
        Else
            strLastName = txtSalariedLastName.Text
        End If
    End Sub

    'Ensures Yearly Salary exists, is numeric, and greater than 0
    Private Sub Get_Validate_YearlySalary(ByRef decYearlySalary As Decimal, ByRef blnValidated As Boolean)
        If Decimal.TryParse(txtSalariedYearlySalary.Text, decYearlySalary) Then
            If decYearlySalary > 0 Then
            Else
                MessageBox.Show("Yearly Salary must be greater than 0!")
                txtSalariedYearlySalary.Focus()
                blnValidated = False
            End If
        Else
            MessageBox.Show("Yearly Salary must exist and be numeric!")
            txtSalariedYearlySalary.Focus()
            blnValidated = False
        End If
    End Sub

    'Ensures YTD Gross Pay exists, is numeric, and greater than or equal to 0
    Private Sub Get_Validate_YTDGrossPay(ByRef decYTDGrossPay As Decimal, ByRef blnValidated As Boolean)
        If Decimal.TryParse(txtSalariedYTDGrossPay.Text, decYTDGrossPay) Then
            If decYTDGrossPay >= 0 Then
            Else
                MessageBox.Show("YTD Gross Pay must be greater than or equal to 0!")
                txtSalariedYTDGrossPay.Focus()
                blnValidated = False
            End If
        Else
            MessageBox.Show("YTD Gross Pay must exist and be numeric!")
            txtSalariedYTDGrossPay.Focus()
            blnValidated = False
        End If
    End Sub

    'Gets selected state from radio buttons
    Private Function Get_State() As String
        If radSalariedOhio.Checked = True Then
            Return "Ohio"
        ElseIf radSalariedKentucky.Checked = True Then
            Return "Kentucky"
        Else
            Return "Indiana"
        End If
    End Function


    'Calls each individual calculation function in order
    Private Sub Calculate_All(ByVal decYearlySalary As Decimal, ByVal decYTDGrossPay As Decimal,
                              ByVal strState As String, ByRef decGrossPay As Decimal,
                              ByRef decSocialSecurity As Decimal,
                               ByRef decMedicare As Decimal, ByRef decFICA As Decimal,
                               ByRef decStateTax As Decimal, ByRef decFederalTax As Decimal,
                               ByRef decNetPay As Decimal)

        decGrossPay = Calculate_GrossPay(decYearlySalary)
        decSocialSecurity = Calculate_SocialSecurity(decYTDGrossPay, decGrossPay)
        decMedicare = Calculate_Medicare(decGrossPay)
        decFICA = Calculate_FICA(decSocialSecurity, decMedicare)
        decStateTax = Calculate_StateTax(decGrossPay, strState)
        decFederalTax = Calculate_FederalTax(decGrossPay)
        decNetPay = Calculate_NetPay(decGrossPay, decFICA, decStateTax, decFederalTax)
        Call Calculate_DailyGrossPay(decGrossPay)
        Call Calculate_DailyNetPay(decNetPay)
    End Sub


    'Calculates Gross Pay based on Yearly Salary divided by number of payrolls per year
    Private Function Calculate_GrossPay(ByVal decYearlySalary As Decimal) As Decimal
        Return decYearlySalary / dec_PAYROLLS_PER_YEAR
    End Function


    'Displays all calculated results to the form labels
    Private Sub Display_Results(ByVal decGrossPay As Decimal, ByVal decFICA As Decimal,
                                 ByVal decStateTax As Decimal, ByVal decFederalTax As Decimal,
                                 ByVal decNetPay As Decimal)

        lblSalariedDisplayGrossPay.Text = decGrossPay.ToString("C")
        lblSalariedDisplayFICA.Text = decFICA.ToString("C")
        lblSalariedDisplayStateTax.Text = decStateTax.ToString("C")
        lblSalariedDisplayFederalTax.Text = decFederalTax.ToString("C")
        lblSalariedDisplayNetPay.Text = decNetPay.ToString("C")
    End Sub


    'Clears all inputs and outputs for next entry
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnSalariedClear.Click

        'Clear all text boxes
        txtSalariedFirstName.Clear()
        txtSalariedLastName.Clear()
        txtSalariedYearlySalary.Clear()
        txtSalariedYTDGrossPay.Clear()

        'Reset radio buttons
        radSalariedOhio.Checked = False
        radSalariedKentucky.Checked = False
        radSalariedIndiana.Checked = True

        'Clear output labels
        lblSalariedDisplayGrossPay.ResetText()
        lblSalariedDisplayFICA.ResetText()
        lblSalariedDisplayStateTax.ResetText()
        lblSalariedDisplayFederalTax.ResetText()
        lblSalariedDisplayNetPay.ResetText()

        'Set focus back to first name
        txtSalariedFirstName.Focus()

    End Sub

    'Closes the Salaried Employee form
    Private Sub btnSalariedExit_Click(sender As Object, e As EventArgs) Handles btnSalariedExit.Click
        Close()
    End Sub

    'Menu item that mimics the Calculate button
    Private Sub mnuCalculate_Click(sender As Object, e As EventArgs) Handles mnuCalculate.Click
        btnSalariedCalculate_Click(sender, e)
    End Sub

    'Menu item that mimics the Clear button
    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        btnClear_Click(sender, e)
    End Sub

    'Menu item that mimics the Exit button
    Private Sub mnuExitForm_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        btnSalariedExit_Click(sender, e)
    End Sub
End Class