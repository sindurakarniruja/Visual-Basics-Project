﻿Public Class frmMain
    'Opens the Salaried Employee form
    Private Sub btnSalariedMenu_Click(sender As Object, e As EventArgs) Handles btnSalariedMenu.Click
        Dim frmSalariedEmployee As New frmSalariedEmployee
        frmSalariedEmployee.ShowDialog()
    End Sub

    'Opens the Hourly Employee form
    Private Sub btnHourlyMenu_Click(sender As Object, e As EventArgs) Handles btnHourlyMenu.Click
        Dim frmHourlyEmployee As New frmHourlyEmployee
        frmHourlyEmployee.ShowDialog()
    End Sub

    'Shows Daily Totals in a MessageBox
    Private Sub btnDailyTotals_Click(sender As Object, e As EventArgs) Handles btnDailyTotals.Click
        MessageBox.Show("Daily Gross Pay: " & decDailyGrossPay.ToString("C") & vbCr &
                        "Daily Net Pay: " & decDailyNetPay.ToString("C"),
                        "Daily Payroll Totals")
    End Sub

    'Closes the application
    Private Sub btnMainExit_Click(sender As Object, e As EventArgs) Handles btnMainExit.Click
        Close()
    End Sub


    'Menu item that mimics the Salaried Employee button
    Private Sub mnuSalariedEmployee_Click(sender As Object, e As EventArgs) Handles mnuSalariedEmployee.Click
        btnSalariedMenu_Click(sender, e)
    End Sub


    'Menu item that mimics the Hourly Employee button
    Private Sub mnuHourlyEmployee_Click(sender As Object, e As EventArgs) Handles mnuHourlyEmployee.Click
        btnHourlyMenu_Click(sender, e)
    End Sub

    'Menu item that mimics the Daily Totals button
    Private Sub mnuViewDailyTotals_Click(sender As Object, e As EventArgs) Handles mnuViewDailyTotals.Click
        btnDailyTotals_Click(sender, e)
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        btnMainExit_Click(sender, e)
    End Sub
End Class
