﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSalariedMenu = New System.Windows.Forms.Button()
        Me.btnHourlyMenu = New System.Windows.Forms.Button()
        Me.btnDailyTotals = New System.Windows.Forms.Button()
        Me.btnMainExit = New System.Windows.Forms.Button()
        Me.Menu = New System.Windows.Forms.MenuStrip()
        Me.mnuActions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSalariedEmployee = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHourlyEmployee = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewDailyTotals = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSalariedMenu
        '
        Me.btnSalariedMenu.Location = New System.Drawing.Point(159, 66)
        Me.btnSalariedMenu.Name = "btnSalariedMenu"
        Me.btnSalariedMenu.Size = New System.Drawing.Size(190, 71)
        Me.btnSalariedMenu.TabIndex = 0
        Me.btnSalariedMenu.Text = "Salaried Employee"
        Me.btnSalariedMenu.UseVisualStyleBackColor = True
        '
        'btnHourlyMenu
        '
        Me.btnHourlyMenu.Location = New System.Drawing.Point(159, 158)
        Me.btnHourlyMenu.Name = "btnHourlyMenu"
        Me.btnHourlyMenu.Size = New System.Drawing.Size(190, 73)
        Me.btnHourlyMenu.TabIndex = 1
        Me.btnHourlyMenu.Text = "Hourly Employed"
        Me.btnHourlyMenu.UseVisualStyleBackColor = True
        '
        'btnDailyTotals
        '
        Me.btnDailyTotals.Location = New System.Drawing.Point(159, 254)
        Me.btnDailyTotals.Name = "btnDailyTotals"
        Me.btnDailyTotals.Size = New System.Drawing.Size(190, 76)
        Me.btnDailyTotals.TabIndex = 2
        Me.btnDailyTotals.Text = "View Daily Totals of Gross and Net Pay"
        Me.btnDailyTotals.UseVisualStyleBackColor = True
        '
        'btnMainExit
        '
        Me.btnMainExit.Location = New System.Drawing.Point(180, 355)
        Me.btnMainExit.Name = "btnMainExit"
        Me.btnMainExit.Size = New System.Drawing.Size(142, 44)
        Me.btnMainExit.TabIndex = 3
        Me.btnMainExit.Text = "Exit"
        Me.btnMainExit.UseVisualStyleBackColor = True
        '
        'Menu
        '
        Me.Menu.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.Menu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuActions})
        Me.Menu.Location = New System.Drawing.Point(0, 0)
        Me.Menu.Name = "Menu"
        Me.Menu.Size = New System.Drawing.Size(552, 33)
        Me.Menu.TabIndex = 4
        Me.Menu.Text = "MenuStrip1"
        '
        'mnuActions
        '
        Me.mnuActions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSalariedEmployee, Me.mnuHourlyEmployee, Me.mnuViewDailyTotals, Me.mnuExit})
        Me.mnuActions.Name = "mnuActions"
        Me.mnuActions.Size = New System.Drawing.Size(87, 29)
        Me.mnuActions.Text = "Actions"
        '
        'mnuSalariedEmployee
        '
        Me.mnuSalariedEmployee.Name = "mnuSalariedEmployee"
        Me.mnuSalariedEmployee.Size = New System.Drawing.Size(270, 34)
        Me.mnuSalariedEmployee.Text = "Salaried Employee"
        '
        'mnuHourlyEmployee
        '
        Me.mnuHourlyEmployee.Name = "mnuHourlyEmployee"
        Me.mnuHourlyEmployee.Size = New System.Drawing.Size(270, 34)
        Me.mnuHourlyEmployee.Text = "Hourly Employee"
        '
        'mnuViewDailyTotals
        '
        Me.mnuViewDailyTotals.Name = "mnuViewDailyTotals"
        Me.mnuViewDailyTotals.Size = New System.Drawing.Size(270, 34)
        Me.mnuViewDailyTotals.Text = "View Daily Totals"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(270, 34)
        Me.mnuExit.Text = "Exit"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 450)
        Me.Controls.Add(Me.btnMainExit)
        Me.Controls.Add(Me.btnDailyTotals)
        Me.Controls.Add(Me.btnHourlyMenu)
        Me.Controls.Add(Me.btnSalariedMenu)
        Me.Controls.Add(Me.Menu)
        Me.MainMenuStrip = Me.Menu
        Me.Name = "frmMain"
        Me.Text = "Main Form"
        Me.Menu.ResumeLayout(False)
        Me.Menu.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSalariedMenu As Button
    Friend WithEvents btnHourlyMenu As Button
    Friend WithEvents btnDailyTotals As Button
    Friend WithEvents btnMainExit As Button
    Friend WithEvents Menu As MenuStrip
    Friend WithEvents mnuActions As ToolStripMenuItem
    Friend WithEvents mnuSalariedEmployee As ToolStripMenuItem
    Friend WithEvents mnuHourlyEmployee As ToolStripMenuItem
    Friend WithEvents mnuViewDailyTotals As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
End Class
