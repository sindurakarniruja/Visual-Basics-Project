﻿Module modStandard
    'Gross Pay Constants
    Private Const dec_FED_RATE_10 As Decimal = 0.1
    Private Const dec_FED_RATE_15 As Decimal = 0.15
    Private Const dec_FED_RATE_20 As Decimal = 0.2
    Private Const dec_FED_RATE_25 As Decimal = 0.25

    Private Const dec_FED_BASE_TAX_UP_TO_500 As Decimal = 45.0
    Private Const dec_FED_BASE_TAX_UP_TO_2500 As Decimal = 345.0
    Private Const dec_FED_BASE_TAX_UP_TO_5000 As Decimal = 845.0


    'FICA Constants
    Private Const dec_SS_RATE As Decimal = 0.062
    Private Const dec_SS_LIMIT As Decimal = 125000
    Private Const dec_MEDICARE_RATE As Decimal = 0.0145

    'State Tax Constants
    Private Const dec_OH_TAX As Decimal = 0.065
    Private Const dec_KY_TAX As Decimal = 0.06
    Private Const dec_IN_TAX As Decimal = 0.055

    'Daily Total Variables
    Public decDailyGrossPay As Decimal
    Public decDailyNetPay As Decimal

    'Calculates Social Security based on YTD Gross Pay and current Gross Pay
    Public Function Calculate_SocialSecurity(ByVal decYTDGrossPay As Decimal, ByVal decGrossPay As Decimal) As Decimal
        If decYTDGrossPay >= dec_SS_LIMIT Then
            Return 0
        ElseIf decYTDGrossPay + decGrossPay > dec_SS_LIMIT Then
            Return (dec_SS_LIMIT - decYTDGrossPay) * dec_SS_RATE
        Else
            Return decGrossPay * dec_SS_RATE
        End If
    End Function

    'Calculates Medicare based on Gross Pay
    Public Function Calculate_Medicare(ByVal decGrossPay As Decimal) As Decimal
        Return decGrossPay * dec_MEDICARE_RATE
    End Function

    'Calculates FICA as sum of Social Security and Medicare
    Public Function Calculate_FICA(ByVal decSocialSecurity As Decimal, ByVal decMedicare As Decimal) As Decimal
        Return decSocialSecurity + decMedicare
    End Function

    'Calculates Federal Tax based on Gross Pay brackets

    Public Function Calculate_FederalTax(ByVal decGrossPay As Decimal) As Decimal
        If decGrossPay <= 50 Then
            Return 0
        ElseIf decGrossPay <= 500 Then
            Return (decGrossPay - 50) * dec_FED_RATE_10
        ElseIf decGrossPay <= 2500 Then
            Return dec_FED_BASE_TAX_UP_TO_500 + (decGrossPay - 500) * dec_FED_RATE_15
        ElseIf decGrossPay <= 5000 Then
            Return dec_FED_BASE_TAX_UP_TO_2500 + (decGrossPay - 2500) * dec_FED_RATE_20
        Else
            Return dec_FED_BASE_TAX_UP_TO_5000 + (decGrossPay - 5000) * dec_FED_RATE_25
        End If
    End Function

    'Calculates Net Pay as Gross Pay minus all deductions
    Public Function Calculate_NetPay(ByVal decGrossPay As Decimal, ByVal decFICA As Decimal,
                                       ByVal decStateTax As Decimal, ByVal decFederalTax As Decimal) As Decimal
        Return decGrossPay - decFICA - decStateTax - decFederalTax
    End Function

    'Calculates State Tax based on selected state and Gross Pay
    Public Function Calculate_StateTax(ByVal decGrossPay As Decimal, ByVal strState As String) As Decimal
        If strState = "Ohio" Then
            Return decGrossPay * dec_OH_TAX
        ElseIf strState = "Kentucky" Then
            Return decGrossPay * dec_KY_TAX
        Else
            Return decGrossPay * dec_IN_TAX
        End If
    End Function

    'Updates Daily Gross Pay
    Public Sub Calculate_DailyGrossPay(ByVal decGrossPay As Decimal)
        decDailyGrossPay += decGrossPay
    End Sub

    'Updates Daily Net Pay
    Public Sub Calculate_DailyNetPay(ByVal decNetPay As Decimal)
        decDailyNetPay += decNetPay
    End Sub
End Module
