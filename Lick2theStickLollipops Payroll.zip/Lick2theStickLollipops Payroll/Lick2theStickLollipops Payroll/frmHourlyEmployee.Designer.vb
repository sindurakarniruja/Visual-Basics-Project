﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHourlyEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpHourlyinputs = New System.Windows.Forms.GroupBox()
        Me.txtHourlyHourlywage = New System.Windows.Forms.TextBox()
        Me.lblHourlyHourlyWage = New System.Windows.Forms.Label()
        Me.txtHourlyYTDGrossPay = New System.Windows.Forms.TextBox()
        Me.txtHourlyHoursWorked = New System.Windows.Forms.TextBox()
        Me.txtHourlyLastName = New System.Windows.Forms.TextBox()
        Me.lblHourlyYTDGrossPay = New System.Windows.Forms.Label()
        Me.lblHourlyHoursWorked = New System.Windows.Forms.Label()
        Me.lblHourlyLastName = New System.Windows.Forms.Label()
        Me.lblHourlyFirstName = New System.Windows.Forms.Label()
        Me.txtHourlyFirstName = New System.Windows.Forms.TextBox()
        Me.grbHourlyState = New System.Windows.Forms.GroupBox()
        Me.radHourlyOhio = New System.Windows.Forms.RadioButton()
        Me.radHourlyKentucky = New System.Windows.Forms.RadioButton()
        Me.radHourlyIndiana = New System.Windows.Forms.RadioButton()
        Me.btnHourlyExit = New System.Windows.Forms.Button()
        Me.btnHourlyClear = New System.Windows.Forms.Button()
        Me.btnHourlyCalculate = New System.Windows.Forms.Button()
        Me.grpSalaryOutput = New System.Windows.Forms.GroupBox()
        Me.lblHourlyDisplayNetPay = New System.Windows.Forms.Label()
        Me.lblHourlyDisplayFederalTax = New System.Windows.Forms.Label()
        Me.lblHourlyDisplayStateTax = New System.Windows.Forms.Label()
        Me.lblHourlyDisplayFICA = New System.Windows.Forms.Label()
        Me.lblHourlyDisplayGrossPay = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ActionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCalculate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExitForm = New System.Windows.Forms.ToolStripMenuItem()
        Me.grpHourlyinputs.SuspendLayout()
        Me.grbHourlyState.SuspendLayout()
        Me.grpSalaryOutput.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpHourlyinputs
        '
        Me.grpHourlyinputs.Controls.Add(Me.txtHourlyHourlywage)
        Me.grpHourlyinputs.Controls.Add(Me.lblHourlyHourlyWage)
        Me.grpHourlyinputs.Controls.Add(Me.txtHourlyYTDGrossPay)
        Me.grpHourlyinputs.Controls.Add(Me.txtHourlyHoursWorked)
        Me.grpHourlyinputs.Controls.Add(Me.txtHourlyLastName)
        Me.grpHourlyinputs.Controls.Add(Me.lblHourlyYTDGrossPay)
        Me.grpHourlyinputs.Controls.Add(Me.lblHourlyHoursWorked)
        Me.grpHourlyinputs.Controls.Add(Me.lblHourlyLastName)
        Me.grpHourlyinputs.Controls.Add(Me.lblHourlyFirstName)
        Me.grpHourlyinputs.Controls.Add(Me.txtHourlyFirstName)
        Me.grpHourlyinputs.Location = New System.Drawing.Point(12, 56)
        Me.grpHourlyinputs.Name = "grpHourlyinputs"
        Me.grpHourlyinputs.Size = New System.Drawing.Size(319, 196)
        Me.grpHourlyinputs.TabIndex = 8
        Me.grpHourlyinputs.TabStop = False
        '
        'txtHourlyHourlywage
        '
        Me.txtHourlyHourlywage.Location = New System.Drawing.Point(126, 127)
        Me.txtHourlyHourlywage.Multiline = True
        Me.txtHourlyHourlywage.Name = "txtHourlyHourlywage"
        Me.txtHourlyHourlywage.Size = New System.Drawing.Size(100, 26)
        Me.txtHourlyHourlywage.TabIndex = 13
        '
        'lblHourlyHourlyWage
        '
        Me.lblHourlyHourlyWage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyHourlyWage.Location = New System.Drawing.Point(6, 127)
        Me.lblHourlyHourlyWage.Name = "lblHourlyHourlyWage"
        Me.lblHourlyHourlyWage.Size = New System.Drawing.Size(114, 20)
        Me.lblHourlyHourlyWage.TabIndex = 14
        Me.lblHourlyHourlyWage.Text = "Hourly Wage:"
        Me.lblHourlyHourlyWage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtHourlyYTDGrossPay
        '
        Me.txtHourlyYTDGrossPay.Location = New System.Drawing.Point(126, 159)
        Me.txtHourlyYTDGrossPay.Multiline = True
        Me.txtHourlyYTDGrossPay.Name = "txtHourlyYTDGrossPay"
        Me.txtHourlyYTDGrossPay.Size = New System.Drawing.Size(100, 26)
        Me.txtHourlyYTDGrossPay.TabIndex = 14
        '
        'txtHourlyHoursWorked
        '
        Me.txtHourlyHoursWorked.Location = New System.Drawing.Point(126, 97)
        Me.txtHourlyHoursWorked.Multiline = True
        Me.txtHourlyHoursWorked.Name = "txtHourlyHoursWorked"
        Me.txtHourlyHoursWorked.Size = New System.Drawing.Size(100, 26)
        Me.txtHourlyHoursWorked.TabIndex = 12
        '
        'txtHourlyLastName
        '
        Me.txtHourlyLastName.Location = New System.Drawing.Point(126, 65)
        Me.txtHourlyLastName.Multiline = True
        Me.txtHourlyLastName.Name = "txtHourlyLastName"
        Me.txtHourlyLastName.Size = New System.Drawing.Size(100, 26)
        Me.txtHourlyLastName.TabIndex = 11
        '
        'lblHourlyYTDGrossPay
        '
        Me.lblHourlyYTDGrossPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyYTDGrossPay.Location = New System.Drawing.Point(0, 159)
        Me.lblHourlyYTDGrossPay.Name = "lblHourlyYTDGrossPay"
        Me.lblHourlyYTDGrossPay.Size = New System.Drawing.Size(131, 20)
        Me.lblHourlyYTDGrossPay.TabIndex = 10
        Me.lblHourlyYTDGrossPay.Text = "YTD Gross Pay:"
        Me.lblHourlyYTDGrossPay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHourlyHoursWorked
        '
        Me.lblHourlyHoursWorked.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyHoursWorked.Location = New System.Drawing.Point(6, 99)
        Me.lblHourlyHoursWorked.Name = "lblHourlyHoursWorked"
        Me.lblHourlyHoursWorked.Size = New System.Drawing.Size(131, 23)
        Me.lblHourlyHoursWorked.TabIndex = 9
        Me.lblHourlyHoursWorked.Text = "Hours Worked:"
        Me.lblHourlyHoursWorked.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHourlyLastName
        '
        Me.lblHourlyLastName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyLastName.Location = New System.Drawing.Point(6, 68)
        Me.lblHourlyLastName.Name = "lblHourlyLastName"
        Me.lblHourlyLastName.Size = New System.Drawing.Size(114, 20)
        Me.lblHourlyLastName.TabIndex = 8
        Me.lblHourlyLastName.Text = "Last Name:"
        Me.lblHourlyLastName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblHourlyFirstName
        '
        Me.lblHourlyFirstName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyFirstName.Location = New System.Drawing.Point(6, 35)
        Me.lblHourlyFirstName.Name = "lblHourlyFirstName"
        Me.lblHourlyFirstName.Size = New System.Drawing.Size(114, 20)
        Me.lblHourlyFirstName.TabIndex = 0
        Me.lblHourlyFirstName.Text = "First Name:"
        Me.lblHourlyFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtHourlyFirstName
        '
        Me.txtHourlyFirstName.Location = New System.Drawing.Point(126, 33)
        Me.txtHourlyFirstName.Multiline = True
        Me.txtHourlyFirstName.Name = "txtHourlyFirstName"
        Me.txtHourlyFirstName.Size = New System.Drawing.Size(100, 26)
        Me.txtHourlyFirstName.TabIndex = 4
        '
        'grbHourlyState
        '
        Me.grbHourlyState.Controls.Add(Me.radHourlyOhio)
        Me.grbHourlyState.Controls.Add(Me.radHourlyKentucky)
        Me.grbHourlyState.Controls.Add(Me.radHourlyIndiana)
        Me.grbHourlyState.Location = New System.Drawing.Point(371, 86)
        Me.grbHourlyState.Name = "grbHourlyState"
        Me.grbHourlyState.Size = New System.Drawing.Size(200, 148)
        Me.grbHourlyState.TabIndex = 16
        Me.grbHourlyState.TabStop = False
        Me.grbHourlyState.Text = "State"
        '
        'radHourlyOhio
        '
        Me.radHourlyOhio.AutoSize = True
        Me.radHourlyOhio.Location = New System.Drawing.Point(16, 109)
        Me.radHourlyOhio.Name = "radHourlyOhio"
        Me.radHourlyOhio.Size = New System.Drawing.Size(67, 24)
        Me.radHourlyOhio.TabIndex = 17
        Me.radHourlyOhio.TabStop = True
        Me.radHourlyOhio.Text = "Ohio"
        Me.radHourlyOhio.UseVisualStyleBackColor = True
        '
        'radHourlyKentucky
        '
        Me.radHourlyKentucky.AutoSize = True
        Me.radHourlyKentucky.Location = New System.Drawing.Point(16, 68)
        Me.radHourlyKentucky.Name = "radHourlyKentucky"
        Me.radHourlyKentucky.Size = New System.Drawing.Size(99, 24)
        Me.radHourlyKentucky.TabIndex = 16
        Me.radHourlyKentucky.TabStop = True
        Me.radHourlyKentucky.Text = "Kentucky"
        Me.radHourlyKentucky.UseVisualStyleBackColor = True
        '
        'radHourlyIndiana
        '
        Me.radHourlyIndiana.AutoSize = True
        Me.radHourlyIndiana.Checked = True
        Me.radHourlyIndiana.Location = New System.Drawing.Point(16, 26)
        Me.radHourlyIndiana.Name = "radHourlyIndiana"
        Me.radHourlyIndiana.Size = New System.Drawing.Size(87, 24)
        Me.radHourlyIndiana.TabIndex = 15
        Me.radHourlyIndiana.TabStop = True
        Me.radHourlyIndiana.Text = "Indiana"
        Me.radHourlyIndiana.UseVisualStyleBackColor = True
        '
        'btnHourlyExit
        '
        Me.btnHourlyExit.Location = New System.Drawing.Point(356, 276)
        Me.btnHourlyExit.Name = "btnHourlyExit"
        Me.btnHourlyExit.Size = New System.Drawing.Size(98, 31)
        Me.btnHourlyExit.TabIndex = 20
        Me.btnHourlyExit.Text = "Exit"
        Me.btnHourlyExit.UseVisualStyleBackColor = True
        '
        'btnHourlyClear
        '
        Me.btnHourlyClear.Location = New System.Drawing.Point(228, 276)
        Me.btnHourlyClear.Name = "btnHourlyClear"
        Me.btnHourlyClear.Size = New System.Drawing.Size(98, 31)
        Me.btnHourlyClear.TabIndex = 19
        Me.btnHourlyClear.Text = "Clear"
        Me.btnHourlyClear.UseVisualStyleBackColor = True
        '
        'btnHourlyCalculate
        '
        Me.btnHourlyCalculate.Location = New System.Drawing.Point(110, 276)
        Me.btnHourlyCalculate.Name = "btnHourlyCalculate"
        Me.btnHourlyCalculate.Size = New System.Drawing.Size(98, 31)
        Me.btnHourlyCalculate.TabIndex = 18
        Me.btnHourlyCalculate.Text = "Calculate"
        Me.btnHourlyCalculate.UseVisualStyleBackColor = True
        '
        'grpSalaryOutput
        '
        Me.grpSalaryOutput.Controls.Add(Me.lblHourlyDisplayNetPay)
        Me.grpSalaryOutput.Controls.Add(Me.lblHourlyDisplayFederalTax)
        Me.grpSalaryOutput.Controls.Add(Me.lblHourlyDisplayStateTax)
        Me.grpSalaryOutput.Controls.Add(Me.lblHourlyDisplayFICA)
        Me.grpSalaryOutput.Controls.Add(Me.lblHourlyDisplayGrossPay)
        Me.grpSalaryOutput.Controls.Add(Me.lbl5)
        Me.grpSalaryOutput.Controls.Add(Me.lbl4)
        Me.grpSalaryOutput.Controls.Add(Me.lbl3)
        Me.grpSalaryOutput.Controls.Add(Me.lbl2)
        Me.grpSalaryOutput.Controls.Add(Me.lbl1)
        Me.grpSalaryOutput.Location = New System.Drawing.Point(94, 330)
        Me.grpSalaryOutput.Name = "grpSalaryOutput"
        Me.grpSalaryOutput.Size = New System.Drawing.Size(321, 200)
        Me.grpSalaryOutput.TabIndex = 20
        Me.grpSalaryOutput.TabStop = False
        Me.grpSalaryOutput.Text = "Results"
        '
        'lblHourlyDisplayNetPay
        '
        Me.lblHourlyDisplayNetPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyDisplayNetPay.Location = New System.Drawing.Point(140, 161)
        Me.lblHourlyDisplayNetPay.Name = "lblHourlyDisplayNetPay"
        Me.lblHourlyDisplayNetPay.Size = New System.Drawing.Size(100, 23)
        Me.lblHourlyDisplayNetPay.TabIndex = 12
        '
        'lblHourlyDisplayFederalTax
        '
        Me.lblHourlyDisplayFederalTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyDisplayFederalTax.Location = New System.Drawing.Point(140, 133)
        Me.lblHourlyDisplayFederalTax.Name = "lblHourlyDisplayFederalTax"
        Me.lblHourlyDisplayFederalTax.Size = New System.Drawing.Size(100, 23)
        Me.lblHourlyDisplayFederalTax.TabIndex = 8
        '
        'lblHourlyDisplayStateTax
        '
        Me.lblHourlyDisplayStateTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyDisplayStateTax.Location = New System.Drawing.Point(140, 101)
        Me.lblHourlyDisplayStateTax.Name = "lblHourlyDisplayStateTax"
        Me.lblHourlyDisplayStateTax.Size = New System.Drawing.Size(100, 23)
        Me.lblHourlyDisplayStateTax.TabIndex = 7
        '
        'lblHourlyDisplayFICA
        '
        Me.lblHourlyDisplayFICA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyDisplayFICA.Location = New System.Drawing.Point(140, 68)
        Me.lblHourlyDisplayFICA.Name = "lblHourlyDisplayFICA"
        Me.lblHourlyDisplayFICA.Size = New System.Drawing.Size(100, 23)
        Me.lblHourlyDisplayFICA.TabIndex = 6
        '
        'lblHourlyDisplayGrossPay
        '
        Me.lblHourlyDisplayGrossPay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblHourlyDisplayGrossPay.Location = New System.Drawing.Point(140, 36)
        Me.lblHourlyDisplayGrossPay.Name = "lblHourlyDisplayGrossPay"
        Me.lblHourlyDisplayGrossPay.Size = New System.Drawing.Size(100, 23)
        Me.lblHourlyDisplayGrossPay.TabIndex = 5
        '
        'lbl5
        '
        Me.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl5.Location = New System.Drawing.Point(25, 161)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(100, 23)
        Me.lbl5.TabIndex = 4
        Me.lbl5.Text = "Net Pay:"
        '
        'lbl4
        '
        Me.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl4.Location = New System.Drawing.Point(25, 130)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(100, 23)
        Me.lbl4.TabIndex = 3
        Me.lbl4.Text = "Federal Tax:"
        '
        'lbl3
        '
        Me.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl3.Location = New System.Drawing.Point(25, 99)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(100, 23)
        Me.lbl3.TabIndex = 2
        Me.lbl3.Text = "State Tax:"
        '
        'lbl2
        '
        Me.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl2.Location = New System.Drawing.Point(25, 66)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(100, 23)
        Me.lbl2.TabIndex = 1
        Me.lbl2.Text = "FICA:"
        '
        'lbl1
        '
        Me.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl1.Location = New System.Drawing.Point(25, 36)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(100, 23)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Gross Pay:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ActionsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(584, 33)
        Me.MenuStrip1.TabIndex = 21
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ActionsToolStripMenuItem
        '
        Me.ActionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCalculate, Me.mnuClear, Me.mnuExitForm})
        Me.ActionsToolStripMenuItem.Name = "ActionsToolStripMenuItem"
        Me.ActionsToolStripMenuItem.Size = New System.Drawing.Size(87, 29)
        Me.ActionsToolStripMenuItem.Text = "Actions"
        '
        'mnuCalculate
        '
        Me.mnuCalculate.Name = "mnuCalculate"
        Me.mnuCalculate.Size = New System.Drawing.Size(189, 34)
        Me.mnuCalculate.Text = "Calculate "
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(189, 34)
        Me.mnuClear.Text = "Clear"
        '
        'mnuExitForm
        '
        Me.mnuExitForm.Name = "mnuExitForm"
        Me.mnuExitForm.Size = New System.Drawing.Size(189, 34)
        Me.mnuExitForm.Text = "Exit Form"
        '
        'frmHourlyEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 567)
        Me.Controls.Add(Me.grpSalaryOutput)
        Me.Controls.Add(Me.btnHourlyExit)
        Me.Controls.Add(Me.btnHourlyClear)
        Me.Controls.Add(Me.btnHourlyCalculate)
        Me.Controls.Add(Me.grbHourlyState)
        Me.Controls.Add(Me.grpHourlyinputs)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmHourlyEmployee"
        Me.Text = "Hourly Employee"
        Me.grpHourlyinputs.ResumeLayout(False)
        Me.grpHourlyinputs.PerformLayout()
        Me.grbHourlyState.ResumeLayout(False)
        Me.grbHourlyState.PerformLayout()
        Me.grpSalaryOutput.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpHourlyinputs As GroupBox
    Friend WithEvents txtHourlyYTDGrossPay As TextBox
    Friend WithEvents txtHourlyHoursWorked As TextBox
    Friend WithEvents txtHourlyLastName As TextBox
    Friend WithEvents lblHourlyYTDGrossPay As Label
    Friend WithEvents lblHourlyHoursWorked As Label
    Friend WithEvents lblHourlyLastName As Label
    Friend WithEvents lblHourlyFirstName As Label
    Friend WithEvents txtHourlyFirstName As TextBox
    Friend WithEvents txtHourlyHourlywage As TextBox
    Friend WithEvents lblHourlyHourlyWage As Label
    Friend WithEvents grbHourlyState As GroupBox
    Friend WithEvents radHourlyOhio As RadioButton
    Friend WithEvents radHourlyKentucky As RadioButton
    Friend WithEvents radHourlyIndiana As RadioButton
    Friend WithEvents btnHourlyExit As Button
    Friend WithEvents btnHourlyClear As Button
    Friend WithEvents btnHourlyCalculate As Button
    Friend WithEvents grpSalaryOutput As GroupBox
    Friend WithEvents lblHourlyDisplayNetPay As Label
    Friend WithEvents lblHourlyDisplayFederalTax As Label
    Friend WithEvents lblHourlyDisplayStateTax As Label
    Friend WithEvents lblHourlyDisplayFICA As Label
    Friend WithEvents lblHourlyDisplayGrossPay As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ActionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuCalculate As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExitForm As ToolStripMenuItem
End Class
